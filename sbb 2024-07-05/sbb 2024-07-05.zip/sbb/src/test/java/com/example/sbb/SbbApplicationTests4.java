//package com.example.sbb;
//
//import static org.junit.jupiter.api.Assertions.assertEquals;
//
//import java.util.Optional;
//
//import org.junit.jupiter.api.Test;
//import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.boot.test.context.SpringBootTest;
//
//import com.example.sbb.question.Question;
//import com.example.sbb.question.QuestionRepository;
//
//
//
//@SpringBootTest
//class SbbApplicationTests4 {
//
//	@Autowired
//	private QuestionRepository questionRepository;
//	
//	@Test
//	void testJpa() {
//		Optional<Question> _q = this.questionRepository.findById(1); // findById(A): ID의 값이 A인 행의 subject의 값이 'subject'가 맞는지 비교
//		if (_q.isPresent()) {
//			Question q = _q.get();
//			assertEquals("subject", q.getSubject());
//		}
//	}
//}
