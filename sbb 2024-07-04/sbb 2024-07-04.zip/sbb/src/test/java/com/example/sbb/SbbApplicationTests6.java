//package com.example.sbb;
//
//import static org.junit.jupiter.api.Assertions.assertEquals;
//
//import org.junit.jupiter.api.Test;
//import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.boot.test.context.SpringBootTest;
//
//import com.example.sbb.question.Question;
//import com.example.sbb.question.QuestionRepository;
//
//@SpringBootTest
//class SbbApplicationTests6 {
//
//	@Autowired
//	private QuestionRepository questionRepository;
//	
//	@Test
//	void testJpa() {
//		// findBySubjectAndContent(subject, content)
//		Question q = this.questionRepository.findBySubjectAndContent("subject", "content");
//		assertEquals(1, q.getId());
//	}
//}
