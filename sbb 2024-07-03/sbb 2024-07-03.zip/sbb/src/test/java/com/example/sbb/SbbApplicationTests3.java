//package com.example.sbb;
//
//import static org.junit.jupiter.api.Assertions.assertEquals;
//
//import java.util.List;
//
//import org.junit.jupiter.api.Test;
//import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.boot.test.context.SpringBootTest;
//
//import com.example.sbb.question.Question;
//import com.example.sbb.question.QuestionRepository;
//
//@SpringBootTest
//class SbbApplicationTests3 {
//
//	@Autowired
//	private QuestionRepository questionRepository;
//	
//	@Test
//	void testJpa() {
//		List<Question> all = this.questionRepository.findAll();
//		// assertEquals(A, B) : A는 해당 테이블 내 전체 행의 개수
//		assertEquals(2, all.size());	// assertEquals(기댓값, 실젯값): 예상한 결과와 실제 결과가 동일한지 확인
//		
//		Question q = all.get(0); // 해당 인덱스의 값 확인
//		assertEquals("subject", q.getSubject()); // 해당 인덱스의 값이 동일한지 비교
//		
////		Question q = all.get(1);
////		assertEquals("subject2", q.getSubject());
//	}
//}
